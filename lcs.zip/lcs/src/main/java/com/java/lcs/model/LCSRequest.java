package com.java.lcs.model;

import lombok.Data;

@Data
public class LCSRequest {

	// private String[] values;
	private SetofStrings setofStrings;

}