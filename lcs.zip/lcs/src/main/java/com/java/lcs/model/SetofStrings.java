package com.java.lcs.model;

import lombok.Data;

@Data
public class SetofStrings {
	private String[] values;
}
