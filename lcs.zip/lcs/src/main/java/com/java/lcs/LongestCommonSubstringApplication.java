package com.java.lcs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LongestCommonSubstringApplication {

	public static void main(String[] args) {
		SpringApplication.run(LongestCommonSubstringApplication.class, args);
	}

}
